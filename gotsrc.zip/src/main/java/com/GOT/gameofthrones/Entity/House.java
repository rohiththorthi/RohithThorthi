package com.GOT.gameofthrones.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class House {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    String name;
    String sigil;
    //many houses has atleast one relationship with a kingdom
    @JsonBackReference
    @ManyToOne
    Kingdom kingdom;
    //Each house has many characters
    @JsonManagedReference
    @OneToMany
    List<Protagonist> members;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSigil() {
        return sigil;
    }

    public void setSigil(String sigil) {
        this.sigil = sigil;
    }

    public Kingdom getKingdom() {
        return kingdom;
    }

    public void setKingdom(Kingdom kingdom) {
        this.kingdom = kingdom;
    }

    public List<Protagonist> getMembers() {
        return members;
    }

    public void setMembers(List<Protagonist> members) {
        this.members = members;
    }

}
