package com.GOT.gameofthrones.Service;

import com.GOT.gameofthrones.Entity.House;

import java.util.List;

public interface HouseService {


    House createHouse(House house);

    List<House> getHouse();
}
