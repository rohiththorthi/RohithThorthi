package com.GOT.gameofthrones.Service;

import com.GOT.gameofthrones.Entity.Kingdom;

import java.util.List;


public interface KingdomService {


    Kingdom createKingdom(Kingdom kingdom);

    List<Kingdom> getAllKingdoms();
}
