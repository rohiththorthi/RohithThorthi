package com.GOT.gameofthrones.Service;

import com.GOT.gameofthrones.Entity.Protagonist;

import java.util.List;

public interface ProtagonistService {
    Protagonist createProtagonist(Protagonist protagonist);

   List<Protagonist> getProtagonist();
}
