package com.GOT.gameofthrones.ServiceImplementation;

import com.GOT.gameofthrones.Entity.Protagonist;
import com.GOT.gameofthrones.Repository.ProtagonistRepository;
import com.GOT.gameofthrones.Service.ProtagonistService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProtagonistServiceImpl implements ProtagonistService {
    private final ProtagonistRepository repository;

    public ProtagonistServiceImpl(ProtagonistRepository repository){
        this.repository=repository;
    }
    @Override
    public Protagonist createProtagonist(Protagonist protagonist) {
        return repository.save(protagonist);

    }

    @Override
    public List<Protagonist> getProtagonist() {
        return repository.findAll();
    }
}
