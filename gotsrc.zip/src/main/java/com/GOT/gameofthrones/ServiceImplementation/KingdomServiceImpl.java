package com.GOT.gameofthrones.ServiceImplementation;

import com.GOT.gameofthrones.Entity.Kingdom;
import com.GOT.gameofthrones.Repository.KingdomRepository;
import com.GOT.gameofthrones.Service.KingdomService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KingdomServiceImpl implements KingdomService {
    private final KingdomRepository repository;

    public KingdomServiceImpl(KingdomRepository repository){
        this.repository=repository;
    }

    @Override
    public Kingdom createKingdom(Kingdom kingdom) {

        return  repository.save(kingdom);
    }

    @Override
    public List<Kingdom> getAllKingdoms() {
        return repository.findAll();
    }
}
