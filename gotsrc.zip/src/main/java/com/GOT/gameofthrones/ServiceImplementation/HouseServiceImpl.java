package com.GOT.gameofthrones.ServiceImplementation;

import com.GOT.gameofthrones.Entity.House;
import com.GOT.gameofthrones.Repository.HouseRepository;
import com.GOT.gameofthrones.Service.HouseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HouseServiceImpl implements HouseService {


    private final HouseRepository repository;

   public HouseServiceImpl(HouseRepository repository){
        this.repository=repository;
    }

    @Override
    public House createHouse(House house) {
        return  repository.save(house);
    }

    @Override
    public List<House> getHouse() {
        return repository.findAll();
    }
}
