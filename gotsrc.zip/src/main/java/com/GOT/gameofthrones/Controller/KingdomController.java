package com.GOT.gameofthrones.Controller;

import com.GOT.gameofthrones.Entity.House;
import com.GOT.gameofthrones.Entity.Kingdom;
import com.GOT.gameofthrones.Entity.Protagonist;
import com.GOT.gameofthrones.Service.KingdomService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/got/v1")
public class KingdomController {
    //Dependency Injection for Kingdom related Service
    private final KingdomService service;
public KingdomController(KingdomService service){
    this.service=service;
}
//create kingdom record
@PostMapping("/kingdom")
public ResponseEntity<Kingdom> createKingdom(@RequestBody Kingdom kingdom){
    for(House house:kingdom.getHouses()){
        house.setKingdom(kingdom);
    }

    Kingdom createdkingdom=service.createKingdom(kingdom);
   return ResponseEntity.status(HttpStatus.CREATED).body(createdkingdom);
}
//get kingdom record
    @GetMapping("/kingdoms")
    public ResponseEntity<List<Kingdom>> getAllKingdoms(){
    List<Kingdom> getkingdom=service.getAllKingdoms();
    return ResponseEntity.status(HttpStatus.OK).body(getkingdom);
    }

}
