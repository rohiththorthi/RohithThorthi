package com.GOT.gameofthrones.Controller;

import com.GOT.gameofthrones.Entity.Protagonist;
import com.GOT.gameofthrones.Service.ProtagonistService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProtagonistController {
    private final  ProtagonistService service;
    public ProtagonistController(ProtagonistService service){
        this.service=service;
    }

    //create protagonist record
    @PostMapping("/protagonist")
    public ResponseEntity<Protagonist> createProtagonist(@RequestBody Protagonist protagonist){
        Protagonist created=service.createProtagonist(protagonist);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);

    }
    // get all protagonist records
    @GetMapping("/protagonists")
    public ResponseEntity<List<Protagonist>> getProtagonist(){
       List<Protagonist>  retrievedProtagonist=service.getProtagonist();
        return ResponseEntity.status(HttpStatus.OK).body(retrievedProtagonist);
    }




}
