package com.GOT.gameofthrones.Controller;

import com.GOT.gameofthrones.Entity.House;
import com.GOT.gameofthrones.Entity.Protagonist;
import com.GOT.gameofthrones.Service.HouseService;
import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class HouseController {

    private final HouseService service;

    public HouseController(HouseService service){
        this.service=service;
    }

    //creating house records
    @PostMapping("/house")
    public ResponseEntity<House> createHouse(@RequestBody House house){
        for(Protagonist protagonist: house.getMembers()){
 protagonist.setHouse(house);
        }

        House houseCreated=service.createHouse(house);
        return ResponseEntity.status(HttpStatus.CREATED).body(houseCreated);
    }

    @GetMapping("/houses")
    public ResponseEntity<List<House>> getHouse(){
      List<House> houses=  service.getHouse();
        return ResponseEntity.status(HttpStatus.OK).body(houses);
    }



}

