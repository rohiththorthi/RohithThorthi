package com.GOT.gameofthrones.Repository;

import com.GOT.gameofthrones.Entity.Protagonist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProtagonistRepository extends JpaRepository<Protagonist,Long> {
}
