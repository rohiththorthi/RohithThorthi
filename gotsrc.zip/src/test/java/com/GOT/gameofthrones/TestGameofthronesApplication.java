package com.GOT.gameofthrones;

import org.springframework.boot.SpringApplication;

public class TestGameofthronesApplication {

	public static void main(String[] args) {
		SpringApplication.from(GameofthronesApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
