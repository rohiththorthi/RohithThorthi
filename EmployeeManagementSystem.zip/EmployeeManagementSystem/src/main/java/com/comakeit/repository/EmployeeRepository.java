package com.comakeit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.comakeit.model.Employee;
@Repository
public interface EmployeeRepository  extends JpaRepository<Employee,Long>{

	
}
