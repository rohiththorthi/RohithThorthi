package com.comakeit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="EmployeeDetails")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long id;
	String name;
	String role;
	String department;
	String nameoftheteam;
	String reportingmanager;
	String email;
	String phoneno;
	String address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getNameoftheteam() {
		return nameoftheteam;
	}
	public void setNameoftheteam(String nameoftheteam) {
		this.nameoftheteam = nameoftheteam;
	}
	public String getReportingmanager() {
		return reportingmanager;
	}
	public void setReportingmanager(String reportingmanager) {
		this.reportingmanager = reportingmanager;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee(String name, String role, String department, String nameoftheteam, String reportingmanager,
			String email, String phoneno, String address) {
		super();
		this.name = name;
		this.role = role;
		this.department = department;
		this.nameoftheteam = nameoftheteam;
		this.reportingmanager = reportingmanager;
		this.email = email;
		this.phoneno = phoneno;
		this.address = address;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
