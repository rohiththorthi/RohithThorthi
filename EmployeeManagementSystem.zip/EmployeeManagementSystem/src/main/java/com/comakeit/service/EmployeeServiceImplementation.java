package com.comakeit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.comakeit.model.Employee;
import com.comakeit.repository.EmployeeRepository;
@Service
public class EmployeeServiceImplementation implements EmployeeService {
	@Autowired
	private EmployeeRepository emprepo;

	/*
	 * public List<Employee> getallemployees() {
	 * 
	 * List<Employee> employee=emprepo.findAll(); return employee; }
	 */

	@Override
	public Employee getemployeeById(Long id) {
		Optional <Employee>optional=emprepo.findById(id);
		Employee employee =null;
		if(optional.isPresent()) {
			throw new RuntimeException("Employee Resource not found at id::"+id);
		}else {
			employee=optional.get();
		}
		
		return employee;
	}

	@Override
	public void addemployee(Employee employee) {
		Employee savedemployee=emprepo.save(employee);
	
	}

	@Override
	public void deleteemployeeByid(Long id) {
		emprepo.deleteById(id);
		
	}

	@Override
	public  void updateemployeeByid(Employee employee) {
	emprepo.save(employee);
		
	}
@Override
	public List<Employee> getallemployees() {
		// TODO Auto-generated method stub
		return emprepo.findAll();
	}

	

	
}