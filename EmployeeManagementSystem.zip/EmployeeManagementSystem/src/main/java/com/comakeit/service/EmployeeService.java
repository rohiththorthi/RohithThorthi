package com.comakeit.service;

import java.util.List;

import com.comakeit.model.Employee;

public interface EmployeeService {

	
	List<Employee>getallemployees();
	Employee getemployeeById(Long id);
	public void addemployee(Employee employee);
	public void deleteemployeeByid(Long id);
	public void updateemployeeByid(Employee employee);
}
