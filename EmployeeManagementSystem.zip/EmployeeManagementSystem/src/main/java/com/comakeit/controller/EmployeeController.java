package com.comakeit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comakeit.model.Employee;
import com.comakeit.service.EmployeeServiceImplementation;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
@Autowired 

	private EmployeeServiceImplementation employeeservice;
	@GetMapping("/getemployeebyid/{id}")
	public ResponseEntity <Employee>getEmployeeByid(@PathVariable (value = "id")Long id)
	{
	Employee employee=employeeservice.getemployeeById(id);
	
	return  ResponseEntity.ok().body(employee);
}
	
@GetMapping("/getemployees")
public List<Employee> getAllEmployees(){
	return employeeservice.getallemployees();
}


@PostMapping("/addemployee")
public  String addemployee(@RequestBody Employee employee) {
	employeeservice.addemployee(employee);
	return addemployee(employee);
	
	
}
@PutMapping("/updateemployee/{id}")
public String updateemployee(@RequestBody Employee employee)
		
{
	
	employeeservice.updateemployeeByid(employee);
	
	return  updateemployee(employee);
	}



@DeleteMapping(" ")

public void deleteemployee(@PathVariable (value="id")Long id) {
	employeeservice.deleteemployeeByid(id);
	
}
}
