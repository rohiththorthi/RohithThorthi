import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Define the House interface based on the data model
export interface Protagonist {
  id: number;
  name: string;
}

export interface House {
  id: number;
  name: string;
  sigil: string;
  members: Protagonist[]; // List of Protagonists in the House
}

export interface Kingdom {
  id: number;
  name: string;
  capital: string;
  houses: {name: string}[]; // List of Houses in the Kingdom
}

@Injectable({
  providedIn: 'root',
})
export class KingdomService {
  private apiUrl = 'http://localhost:8080/got/v1/kingdoms'; // Update with your actual backend API endpoint

  constructor(private http: HttpClient) {}

  getKingdoms(): Observable<Kingdom[]> {
    return this.http.get<Kingdom[]>(this.apiUrl);
  }
}
