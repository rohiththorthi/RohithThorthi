import { Component } from '@angular/core';

@Component({
  selector: 'app-protagonist',
  imports: [],
  templateUrl: './protagonist.component.html',
  styleUrl: './protagonist.component.css'
})
export class ProtagonistComponent {

}
