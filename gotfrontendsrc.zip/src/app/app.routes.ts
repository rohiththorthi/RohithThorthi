import { Routes } from '@angular/router';
import { KingdomComponent} from './kingdom/kingdom.component';
export const routes: Routes = [] =[
  { path: '',component:KingdomComponent
    }];
