import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KingdomComponent } from './kingdom.component';

describe('KingdomComponent', () => {
  let component: KingdomComponent;
  let fixture: ComponentFixture<KingdomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KingdomComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KingdomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
