import { Component, OnInit } from '@angular/core';
import { KingdomService, Kingdom } from '../kingdom.service';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-kingdom',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './kingdom.component.html',
  styleUrls: ['./kingdom.component.css'],  // Corrected here
})
export class KingdomComponent implements OnInit {
  kingdoms: Kingdom[] = [];

  constructor(private kingdomService: KingdomService) {}

  ngOnInit() {
    this.kingdomService.getKingdoms().subscribe((data) => {
      this.kingdoms = data;
    });
  }
}
