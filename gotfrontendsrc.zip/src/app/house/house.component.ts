import { Component } from '@angular/core';

@Component({
  selector: 'app-house',
  imports: [],
  templateUrl: './house.component.html',
  styleUrl: './house.component.css'
})
export class HouseComponent {

}
