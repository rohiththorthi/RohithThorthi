
package CollectionFramework;
import java.util.Hashtable;
import java.util.Vector;

public class ArrayVEectorHashtable {

	
	public static void main(String[] args) {
		
		
		int arr[]=new int[] {1,2,3,4,5};
		
		Vector<Integer>v=new Vector();
		v.addElement(6787);
		v.addElement(6857);
		Hashtable <Integer,String>h=new Hashtable();
		h.put(1, "Geeks");
		h.put(2, "For Geeks");
		
		
		System.out.println(arr[0]);
		System.out.println(v.elementAt(1));
		System.out.println(h.get(1));
		for(int i=0;i<5;i++) {
			System.out.println(arr[i]);
		}
		
		for(int i=0;i<2;i++) {
			System.out.println(v.elementAt(i));
		}
		
		for(int i=0;i<=2;i++) {
			System.out.println(h.get(i));
		}
	}
	
	
}
