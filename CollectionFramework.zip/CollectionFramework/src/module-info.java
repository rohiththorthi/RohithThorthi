module CollectionFramework {
}